class DNSRecord:
  def __init__(self, source: str, target: str) -> None:
    self.source = source
    self.target = target
