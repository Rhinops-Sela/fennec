from .core_dns import CoreDNS
from .dns_record import DNSRecord
